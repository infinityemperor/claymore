./ethdcrminer64 -epool asia1.ethermine.org:4444 -ewal 0x2f35b6037AD09A328D37e22DAF93eB751D64feF8.0103 -epsw x -di 01234567 -mport 0 -ethi 7
